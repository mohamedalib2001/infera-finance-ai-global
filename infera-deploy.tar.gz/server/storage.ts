import { db } from "./db";
import {
  subscribers,
  type CreateSubscriberRequest,
  type SubscriberResponse
} from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  createSubscriber(subscriber: CreateSubscriberRequest): Promise<SubscriberResponse>;
  getSubscriberByEmail(email: string): Promise<SubscriberResponse | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getSubscriberByEmail(email: string): Promise<SubscriberResponse | undefined> {
    const [subscriber] = await db.select().from(subscribers).where(eq(subscribers.email, email));
    return subscriber;
  }

  async createSubscriber(createSubscriber: CreateSubscriberRequest): Promise<SubscriberResponse> {
    const [subscriber] = await db.insert(subscribers).values(createSubscriber).returning();
    return subscriber;
  }
}

export const storage = new DatabaseStorage();
